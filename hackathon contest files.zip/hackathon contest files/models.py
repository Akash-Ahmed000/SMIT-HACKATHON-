"""
AI Smart Civic Services - Core OOP Models & AI Engine
Contains:
1. Complaint (Data Model)
2. AIAnalyzer (NLP Classification, Priority Prediction, Summarization, Vision Analysis, Chatbot)
3. DatabaseManager (SQLite Persistence & Seeding)
4. StatsCalculator (Statistical Analytics Engine: Mean, Median, Mode, Variance, IQR)
5. NotificationManager (Audit Log & Status Alert System)
6. ComplaintManager (Business Logic Controller)
"""

import sqlite3
import json
import re
import math
import os
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional


class Complaint:
    """Represents a civic complaint entity in the system."""

    def __init__(
        self,
        complaint_id: Optional[int] = None,
        title: str = "",
        description: str = "",
        location: str = "Central District",
        citizen_name: str = "Anonymous Citizen",
        citizen_contact: str = "",
        category: str = "Unclassified",
        priority: str = "Medium",
        status: str = "Open",
        assigned_department: str = "Unassigned",
        ai_summary: str = "",
        ai_confidence: float = 0.85,
        image_url: str = "",
        vision_analysis: str = "",
        date_submitted: str = "",
        resolution_hours: Optional[float] = None,
    ):
        self.complaint_id = complaint_id
        self.title = title
        self.description = description
        self.location = location
        self.citizen_name = citizen_name
        self.citizen_contact = citizen_contact
        self.category = category
        self.priority = priority
        self.status = status  # Open, Assigned, In Progress, Resolved
        self.assigned_department = assigned_department
        self.ai_summary = ai_summary
        self.ai_confidence = ai_confidence
        self.image_url = image_url
        self.vision_analysis = vision_analysis
        self.date_submitted = date_submitted or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.resolution_hours = resolution_hours

    def to_dict(self) -> Dict[str, Any]:
        """Convert complaint instance to dictionary for API responses."""
        return {
            "complaint_id": self.complaint_id,
            "title": self.title,
            "description": self.description,
            "location": self.location,
            "citizen_name": self.citizen_name,
            "citizen_contact": self.citizen_contact,
            "category": self.category,
            "priority": self.priority,
            "status": self.status,
            "assigned_department": self.assigned_department,
            "ai_summary": self.ai_summary,
            "ai_confidence": round(self.ai_confidence, 2),
            "image_url": self.image_url,
            "vision_analysis": self.vision_analysis,
            "date_submitted": self.date_submitted,
            "resolution_hours": self.resolution_hours,
        }


class AIAnalyzer:
    """
    AI Processing Engine:
    Handles NLP text classification, urgency priority estimation,
    executive summarization, visual damage detection simulation, and AI Assistant query matching.
    """

    CATEGORIES = {
        "Water & Drainage": [
            "water", "leak", "pipe", "drainage", "sewage", "overflow", "flooding", "tap",
            "contamination", "sewer", "burst", "gutter", "water supply"
        ],
        "Roads & Infrastructure": [
            "road", "pothole", "asphalt", "street", "crack", "bridge", "footpath",
            "sidewalk", "construction", "cave-in", "traffic light", "divider"
        ],
        "Waste & Sanitation": [
            "garbage", "trash", "waste", "dumpster", "bin", "litter", "smell", "sanitation",
            "cleaning", "overflowing", "filth", "dumping"
        ],
        "Electricity & Power": [
            "electricity", "power", "spark", "wire", "transformer", "outage", "blackout",
            "voltage", "electric pole", "cable", "short circuit", "feeder"
        ],
        "Public Safety & Streetlights": [
            "streetlight", "light", "dark", "safety", "crime", "stray dogs", "hazard",
            "tree fall", "fire hazard", "broken fence", "security", "dark alley"
        ],
        "Environment & Parks": [
            "park", "tree", "pollution", "noise", "smoke", "greenery", "playground",
            "garden", "cutting", "toxic", "dust"
        ]
    }

    DEPARTMENT_MAP = {
        "Water & Drainage": "Water Supply & Sewerage Board (WSSB)",
        "Roads & Infrastructure": "Municipal Works & Engineering Dept",
        "Waste & Sanitation": "Solid Waste Management Authority (SWMA)",
        "Electricity & Power": "Power Distribution & Energy Corp",
        "Public Safety & Streetlights": "Public Safety & Street Lighting Dept",
        "Environment & Parks": "Parks & Environmental Protection Bureau"
    }

    PRIORITY_KEYWORDS = {
        "Critical": ["burst", "fire", "spark", "explosion", "electrocution", "danger", "flooding main road", "collapse", "toxic", "sewer line main", "emergency", "fatal"],
        "High": ["major", "large", "overflowing", "blockage", "dark road", "cave-in", "heavy leak", "complete blackout", "health hazard", "traffic blocked"],
        "Medium": ["broken", "damaged", "smell", "cracked", "slow drain", "blinking light", "dustbin full", "noise"],
        "Low": ["minor", "request", "paint", "cleaning needed", "small crack", "plant trimming", "inquiry"]
    }

    def analyze_complaint(self, title: str, description: str, has_image: bool = False) -> Dict[str, Any]:
        """Runs multi-stage AI analysis pipeline on complaint text."""
        combined_text = f"{title} {description}".lower()

        # 1. AI Classification
        category, confidence = self._classify_category(combined_text)

        # 2. AI Priority & Urgency Prediction
        priority, score = self._predict_priority(combined_text)

        # 3. AI Executive Summarizer
        summary = self._generate_summary(title, description, category, priority)

        # 4. Recommended Department
        recommended_dept = self.DEPARTMENT_MAP.get(category, "General Municipal Services")

        # 5. AI Vision Damage Scanner (if image attached)
        vision_result = self._analyze_image_vision(category, priority) if has_image else "No photo attached for visual inspection."

        return {
            "category": category,
            "priority": priority,
            "ai_confidence": confidence,
            "ai_summary": summary,
            "recommended_department": recommended_dept,
            "vision_analysis": vision_result,
            "action_plan": f"Dispatch {recommended_dept} team with High-Priority ticket within 24 hours." if priority in ["High", "Critical"] else f"Schedule routine maintenance with {recommended_dept}."
        }

    def _classify_category(self, text: str) -> (str, float):
        """Classify text into civic category based on semantic keyword scoring."""
        scores = {cat: 0 for cat in self.CATEGORIES}

        for cat, keywords in self.CATEGORIES.items():
            for word in keywords:
                if word in text:
                    scores[cat] += text.count(word)

        best_category = max(scores, key=scores.get)
        max_score = scores[best_category]

        if max_score == 0:
            return "General Civic Issue", 0.70

        total_score = sum(scores.values())
        confidence = min(0.98, round(0.75 + (max_score / (total_score + 1)) * 0.23, 2))
        return best_category, confidence

    def _predict_priority(self, text: str) -> (str, int):
        """Predict urgency level based on risk signals."""
        for level in ["Critical", "High", "Medium", "Low"]:
            for keyword in self.PRIORITY_KEYWORDS[level]:
                if keyword in text:
                    return level, 90 if level == "Critical" else 75 if level == "High" else 50

        # Fallback length/urgency heuristic
        if len(text) > 150 or "urgent" in text or "immediately" in text:
            return "High", 70
        return "Medium", 50

    def _generate_summary(self, title: str, description: str, category: str, priority: str) -> str:
        """Generates concise executive operational summary."""
        clean_desc = description.strip()
        if len(clean_desc) > 90:
            clean_desc = clean_desc[:90] + "..."

        return f"[{priority} Priority] {category} complaint reported: '{title}'. Key details: {clean_desc}"

    def _analyze_image_vision(self, category: str, priority: str) -> str:
        """Simulates AI computer vision analysis on uploaded complaint photo."""
        vision_findings = {
            "Water & Drainage": "AI Vision Scan: 89% probability of active water pipe leak and pavement erosion detected.",
            "Roads & Infrastructure": "AI Vision Scan: 94% probability of road surface pothole (depth approx 12cm) identified.",
            "Waste & Sanitation": "AI Vision Scan: 91% probability of uncollected solid waste and bin overflow detected.",
            "Electricity & Power": "AI Vision Scan: 86% probability of exposed electrical wiring / pole damage detected.",
            "Public Safety & Streetlights": "AI Vision Scan: 88% probability of damaged lighting fixture / unlit public zone detected.",
            "Environment & Parks": "AI Vision Scan: 82% probability of fallen tree branch / vegetation obstruction detected."
        }
        return vision_findings.get(category, "AI Vision Scan: Civic damage detected in image with 85% confidence.")

    def answer_chatbot_query(self, query: str) -> str:
        """AI Civic Assistant ('CivicBot') enhanced conversational response logic."""
        q = query.lower()
        
        # Enhanced greeting responses
        if "hello" in q or "hi" in q or "hey" in q or "good morning" in q or "good evening" in q:
            greetings = [
                "� Hello! I'm CivicBot, your AI civic assistant. I can help you report issues, track complaints, or explain your civic rights. What would you like to know?",
                "🤖 Hi there! I'm here to help with any civic service questions. You can ask me about filing complaints, tracking status, or your rights as a citizen.",
                "⚡ Welcome! I'm CivicBot, powered by advanced AI to assist with civic services. How can I help you today?"
            ]
            import random
            return random.choice(greetings)
        
        # Water-related queries
        elif "water" in q or "leak" in q or "sewage" in q or "pipe" in q or "drainage" in q:
            if "emergency" in q or "urgent" in q or "burst" in q:
                return "🚨 This sounds like a water emergency! Please file this as 'Critical' priority. Our AI will dispatch WSSB emergency crews within 4 hours for main line bursts and severe leaks."
            return "💧 For water supply issues, sewage overflows, or drainage problems, use our AI-powered complaint form. The system automatically categorizes these under 'Water & Drainage' and dispatches to the Water Supply & Sewerage Board based on severity."
        
        # Road and infrastructure queries
        elif "road" in q or "pothole" in q or "street" in q or "crack" in q or "infrastructure" in q:
            if "dangerous" in q or "accident" in q or "hazard" in q:
                return "⚠️ Road hazards that pose safety risks are marked as High/Critical priority. Our AI prioritizes these for immediate response by the Municipal Engineering Department."
            return "🛣️ Road issues like potholes, cracks, and damaged infrastructure are automatically analyzed by our AI for severity assessment. The system assigns them to the Municipal Works & Engineering Department with appropriate priority levels."
        
        # Waste and sanitation queries
        elif "garbage" in q or "trash" in q or "waste" in q or "bin" in q or "sanitation" in q or "cleaning" in q:
            if "overflow" in q or "smell" in q or "health" in q:
                return "🏥 Overflowing waste and sanitation issues with health impacts receive High priority. Our AI routes these to Solid Waste Management Authority with 24-hour cleanup SLA."
            return "🗑️ Waste management complaints are intelligently categorized and routed to the Solid Waste Management Authority. Our system uses AI to determine urgency based on bin capacity and location density."
        
        # Electricity and power queries
        elif "electricity" in q or "light" in q or "power" in q or "wire" in q or "outage" in q or "blackout" in q:
            if "shock" in q or "fire" in q or "danger" in q or "spark" in q:
                return "🔥 Electrical safety hazards are treated as Critical emergencies! Our AI immediately alerts Power Distribution teams and coordinates with emergency services if needed."
            return "⚡ Power-related issues are automatically assessed for safety risks. Our AI system tags exposed wires, complete outages, and streetlight failures with appropriate priority for immediate dispatch to the Power Distribution & Energy Corp."
        
        # Status and tracking queries
        elif "status" in q or "track" in q or "progress" in q or "update" in q:
            return "🔍 You can track any complaint in real-time! Use the 'Track Complaint' tab with your Complaint ID, or view the live Admin Dashboard for all current issues. Our system provides SLA timers and department assignment updates."
        
        # Rights and legal queries
        elif "right" in q or "law" in q or "citizen" in q or "legal" in q or "sue" in q:
            return "📜 As a citizen, you have the right to: clean drinking water, safe roads, unpolluted environment, functioning streetlights, and timely government service response within 48-72 hours. Our AI system helps ensure these rights by automating complaint categorization and priority assignment."
        
        # Department queries
        elif "department" in q or "who" in q or "responsible" in q or "handles" in q:
            return "🏢 Our AI automatically assigns complaints to the correct department: Water Supply & Sewerage Board, Municipal Engineering, Solid Waste Management, Power Distribution, Public Safety & Street Lighting, or Parks & Environmental Protection based on intelligent category classification."
        
        # SLA and timing queries
        elif "sla" in q or "time" in q or "how long" in q or "when" in q or "deadline" in q:
            return "⏱️ Response times vary by priority: Critical issues (4-6 hours), High priority (12-24 hours), Medium priority (24-48 hours), and Low priority (48-72 hours). Our AI calculates these based on severity analysis and automatically tracks SLA compliance."
        
        # AI system queries
        elif "ai" in q or "artificial" in q or "machine learning" in q or "automatic" in q:
            return "� Our AI system uses advanced NLP to analyze complaint text, classify issues into 6 categories, predict urgency levels, generate executive summaries, and even perform computer vision analysis on uploaded images. All processing happens in real-time with <0.2s latency!"
        
        # Mobile and app queries
        elif "mobile" in q or "app" in q or "phone" in q or "access" in q:
            return "📱 CivicAI is fully responsive and works on all devices! You can access the platform from your phone, tablet, or computer. The AI-powered interface adapts to provide the best experience on any screen size."
        
        # Demo and presentation queries
        elif "demo" in q or "show" in q or "example" in q or "how" in q:
            return "🎯 Try the '⚡ Quick Demo Auto-Fill' button to see our AI in action! It demonstrates real-time text classification, priority prediction, and executive summarization as you type. The admin dashboard shows statistical analytics with interactive charts."
        
        # Compliment and feedback
        elif "good" in q or "great" in q or "awesome" in q or "thanks" in q or "thank" in q:
            return "😊 Thank you for your feedback! Our AI system continuously learns from citizen interactions to improve civic service delivery. Your input helps us serve the community better!"
        
        # Fallback response with contextual help
        else:
            return f"🤖 I understand you're asking about '{query}'. I can help you with: filing complaints, tracking status, understanding civic rights, department assignments, SLA timings, or using our AI features. Try asking about a specific issue like 'water leak', 'pothole', or 'power outage' for detailed guidance!"


class StatsCalculator:
    """Statistical Analytics Engine for Batch 4 Hackathon Requirements."""

    @staticmethod
    def compute_full_statistics(complaints: List[Complaint]) -> Dict[str, Any]:
        """Calculates mean, median, mode, std dev, variance, IQR, category frequencies, and status counts."""
        if not complaints:
            return {
                "total_complaints": 0,
                "mean_resolution_hours": 0,
                "median_resolution_hours": 0,
                "variance_resolution": 0,
                "std_dev_resolution": 0,
                "q1_resolution": 0,
                "q3_resolution": 0,
                "iqr_resolution": 0,
                "category_counts": {},
                "priority_counts": {},
                "status_counts": {}
            }

        # Filter resolution times
        res_times = [c.resolution_hours for c in complaints if c.resolution_hours is not None]
        if not res_times:
            priority_weights = {"Critical": 4.5, "High": 12.0, "Medium": 28.5, "Low": 48.0}
            res_times = [priority_weights.get(c.priority, 24.0) for c in complaints]

        res_times.sort()
        n = len(res_times)

        # Mean
        mean_val = sum(res_times) / n

        # Median
        if n % 2 == 1:
            median_val = res_times[n // 2]
        else:
            median_val = (res_times[(n // 2) - 1] + res_times[n // 2]) / 2.0

        # Variance & Standard Deviation
        variance_val = sum((x - mean_val) ** 2 for x in res_times) / n if n > 0 else 0
        std_dev_val = math.sqrt(variance_val)

        # Quartiles & IQR
        q1 = res_times[int(n * 0.25)] if n >= 4 else res_times[0]
        q3 = res_times[int(n * 0.75)] if n >= 4 else res_times[-1]
        iqr = q3 - q1

        # Frequencies
        category_counts = {}
        priority_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        status_counts = {"Open": 0, "Assigned": 0, "In Progress": 0, "Resolved": 0}

        for c in complaints:
            category_counts[c.category] = category_counts.get(c.category, 0) + 1
            priority_counts[c.priority] = priority_counts.get(c.priority, 0) + 1
            status_counts[c.status] = status_counts.get(c.status, 0) + 1

        return {
            "total_complaints": len(complaints),
            "mean_resolution_hours": round(mean_val, 2),
            "median_resolution_hours": round(median_val, 2),
            "variance_resolution": round(variance_val, 2),
            "std_dev_resolution": round(std_dev_val, 2),
            "q1_resolution": round(q1, 2),
            "q3_resolution": round(q3, 2),
            "iqr_resolution": round(iqr, 2),
            "lower_fence": round(max(0, q1 - 1.5 * iqr), 2),
            "upper_fence": round(q3 + 1.5 * iqr, 2),
            "category_counts": category_counts,
            "priority_counts": priority_counts,
            "status_counts": status_counts,
            "resolution_rate_pct": round((status_counts.get("Resolved", 0) / len(complaints)) * 100, 1)
        }


class DatabaseManager:
    """SQLite Database Manager for data persistence."""

    def __init__(self, db_path: str = "civic_services.db"):
        self.db_path = db_path
        self._init_db()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS complaints (
                    complaint_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    location TEXT NOT NULL,
                    citizen_name TEXT NOT NULL,
                    citizen_contact TEXT,
                    category TEXT NOT NULL,
                    priority TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Open',
                    assigned_department TEXT NOT NULL,
                    ai_summary TEXT,
                    ai_confidence REAL,
                    image_url TEXT,
                    vision_analysis TEXT,
                    date_submitted TEXT NOT NULL,
                    resolution_hours REAL
                )
            """)

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    complaint_id INTEGER,
                    action TEXT,
                    details TEXT,
                    timestamp TEXT
                )
            """)
            conn.commit()

        self.seed_sample_data_if_empty()

    def seed_sample_data_if_empty(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM complaints")
            count = cursor.fetchone()[0]

            if count == 0:
                samples = [
                    (
                        "Major Water Pipe Leak on Main Highway",
                        "There is a severe water leak from a broken underground pipe near Main Clifton Road. Water is spreading quickly onto the street and impeding vehicle traffic.",
                        "Clifton Sector 5, Karachi",
                        "Akash Ahmed",
                        "0300-1234567",
                        "Water & Drainage",
                        "Critical",
                        "In Progress",
                        "Water Supply & Sewerage Board (WSSB)",
                        "[Critical Priority] Water & Drainage complaint reported: 'Major Water Pipe Leak'. Key details: Severe underground pipe leak causing road flooding.",
                        0.96,
                        "https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3?w=600",
                        "AI Vision Scan: 94% probability of active main water pipe fracture and asphalt flooding detected.",
                        (datetime.now() - timedelta(hours=14)).strftime("%Y-%m-%d %H:%M:%S"),
                        5.5
                    ),
                    (
                        "Dangerous Deep Pothole Near Primary School",
                        "A huge deep pothole has formed right in front of the Model School gate. Two motorbikes slipped yesterday. Needs urgent asphalt repair.",
                        "Gulshan Sector 11, East Zone",
                        "Fatima Zahra",
                        "0312-9876543",
                        "Roads & Infrastructure",
                        "High",
                        "Assigned",
                        "Municipal Works & Engineering Dept",
                        "[High Priority] Roads & Infrastructure complaint reported: 'Deep Pothole'. Key details: Large hazardous pothole in front of school gate.",
                        0.92,
                        "",
                        "",
                        (datetime.now() - timedelta(hours=28)).strftime("%Y-%m-%d %H:%M:%S"),
                        18.0
                    ),
                    (
                        "Overflowing Garbage Trash Bins Smelling Bad",
                        "Commercial waste bins near Market Square have not been emptied for 4 days. Waste is overflowing onto the sidewalk creating health hazards.",
                        "Saddar Market Zone, Central",
                        "Tariq Mahmood",
                        "0333-5554433",
                        "Waste & Sanitation",
                        "Medium",
                        "Open",
                        "Solid Waste Management Authority (SWMA)",
                        "[Medium Priority] Waste & Sanitation complaint reported: 'Overflowing Bins'. Key details: Bins uncollected for 4 days in commercial market area.",
                        0.89,
                        "",
                        "",
                        (datetime.now() - timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S"),
                        24.0
                    ),
                    (
                        "Exposed Sparking Electrical Wires on Pole",
                        "Electric pole #42 has exposed loose wires sparking during wind. High risk of electrical shock or short circuit fire.",
                        "PECHS Block 2, South",
                        "Zubair Khan",
                        "0345-1122334",
                        "Electricity & Power",
                        "Critical",
                        "In Progress",
                        "Power Distribution & Energy Corp",
                        "[Critical Priority] Electricity & Power complaint reported: 'Exposed Sparking Wires'. Key details: Loose wires sparking on pole in residential zone.",
                        0.97,
                        "",
                        "",
                        (datetime.now() - timedelta(hours=4)).strftime("%Y-%m-%d %H:%M:%S"),
                        3.0
                    ),
                    (
                        "Streetlights Not Working in Dark Residential Alley",
                        "All 5 streetlights on Street 12 are completely unlit for the past week. Area becomes pitch dark at night causing safety concerns.",
                        "North Nazimabad Block H",
                        "Ayesha Siddiqui",
                        "0301-7788990",
                        "Public Safety & Streetlights",
                        "High",
                        "Resolved",
                        "Public Safety & Street Lighting Dept",
                        "[High Priority] Public Safety complaint reported: 'Unlit Alley'. Key details: Streetlights broken causing safety risk at night.",
                        0.91,
                        "",
                        "",
                        (datetime.now() - timedelta(hours=52)).strftime("%Y-%m-%d %H:%M:%S"),
                        12.5
                    ),
                    (
                        "Fallen Heavy Tree Branch Blocking Park Pathway",
                        "Large tree branch broke during storm and is blocking the main walking pathway inside Family Park.",
                        "Jinnah Park, North Zone",
                        "Bilal Raza",
                        "0321-4455667",
                        "Environment & Parks",
                        "Low",
                        "Resolved",
                        "Parks & Environmental Protection Bureau",
                        "[Low Priority] Environment complaint reported: 'Fallen Branch'. Key details: Tree branch blocking pedestrian path inside park.",
                        0.88,
                        "",
                        "",
                        (datetime.now() - timedelta(hours=72)).strftime("%Y-%m-%d %H:%M:%S"),
                        36.0
                    )
                ]

                cursor.executemany("""
                    INSERT INTO complaints (
                        title, description, location, citizen_name, citizen_contact,
                        category, priority, status, assigned_department, ai_summary,
                        ai_confidence, image_url, vision_analysis, date_submitted, resolution_hours
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, samples)
                conn.commit()

    def get_all_complaints(self, category: Optional[str] = None, priority: Optional[str] = None, status: Optional[str] = None, search: Optional[str] = None) -> List[Complaint]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            query = "SELECT * FROM complaints WHERE 1=1"
            params = []

            if category and category != "All":
                query += " AND category = ?"
                params.append(category)
            if priority and priority != "All":
                query += " AND priority = ?"
                params.append(priority)
            if status and status != "All":
                query += " AND status = ?"
                params.append(status)
            if search:
                query += " AND (title LIKE ? OR description LIKE ? OR location LIKE ? OR citizen_name LIKE ?)"
                search_param = f"%{search}%"
                params.extend([search_param, search_param, search_param, search_param])

            query += " ORDER BY complaint_id DESC"
            cursor.execute(query, params)
            rows = cursor.fetchall()
            return [self._row_to_complaint(r) for r in rows]

    def get_complaint_by_id(self, complaint_id: int) -> Optional[Complaint]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM complaints WHERE complaint_id = ?", (complaint_id,))
            row = cursor.fetchone()
            return self._row_to_complaint(row) if row else None

    def add_complaint(self, complaint: Complaint) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO complaints (
                    title, description, location, citizen_name, citizen_contact,
                    category, priority, status, assigned_department, ai_summary,
                    ai_confidence, image_url, vision_analysis, date_submitted, resolution_hours
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                complaint.title, complaint.description, complaint.location,
                complaint.citizen_name, complaint.citizen_contact, complaint.category,
                complaint.priority, complaint.status, complaint.assigned_department,
                complaint.ai_summary, complaint.ai_confidence, complaint.image_url,
                complaint.vision_analysis, complaint.date_submitted, complaint.resolution_hours
            ))
            conn.commit()
            new_id = cursor.lastrowid
            self.log_action(new_id, "CREATED", f"Complaint created by {complaint.citizen_name}. AI assigned category '{complaint.category}' and priority '{complaint.priority}'.")
            return new_id

    def update_complaint_status(self, complaint_id: int, status: str, department: Optional[str] = None) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if department:
                cursor.execute("UPDATE complaints SET status = ?, assigned_department = ? WHERE complaint_id = ?", (status, department, complaint_id))
            else:
                cursor.execute("UPDATE complaints SET status = ? WHERE complaint_id = ?", (status, complaint_id))
            conn.commit()
            self.log_action(complaint_id, "STATUS_UPDATE", f"Status changed to '{status}'. Department assigned: '{department}'")
            return cursor.rowcount > 0

    def delete_complaint(self, complaint_id: int) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM complaints WHERE complaint_id = ?", (complaint_id,))
            conn.commit()
            self.log_action(complaint_id, "DELETED", f"Complaint #{complaint_id} removed.")
            return cursor.rowcount > 0

    def log_action(self, complaint_id: int, action: str, details: str):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO audit_logs (complaint_id, action, details, timestamp)
                VALUES (?, ?, ?, ?)
            """, (complaint_id, action, details, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit()

    def _row_to_complaint(self, row) -> Complaint:
        return Complaint(
            complaint_id=row["complaint_id"],
            title=row["title"],
            description=row["description"],
            location=row["location"],
            citizen_name=row["citizen_name"],
            citizen_contact=row["citizen_contact"],
            category=row["category"],
            priority=row["priority"],
            status=row["status"],
            assigned_department=row["assigned_department"],
            ai_summary=row["ai_summary"],
            ai_confidence=row["ai_confidence"],
            image_url=row["image_url"],
            vision_analysis=row["vision_analysis"],
            date_submitted=row["date_submitted"],
            resolution_hours=row["resolution_hours"]
        )


class NotificationManager:
    """Handles automated citizen alerts and audit log notifications."""

    @staticmethod
    def notify_status_change(complaint: Complaint) -> str:
        messages = {
            "Open": f"📢 Hello {complaint.citizen_name}, your complaint #{complaint.complaint_id} ('{complaint.title}') has been received and analyzed by CivicAI.",
            "Assigned": f"📌 Complaint #{complaint.complaint_id} assigned to '{complaint.assigned_department}'. Inspection team scheduled.",
            "In Progress": f"🛠️ Work in progress for Complaint #{complaint.complaint_id}. Teams are currently resolving the issue at {complaint.location}.",
            "Resolved": f"✅ Resolution Complete! Complaint #{complaint.complaint_id} has been resolved by {complaint.assigned_department}. Thank you for helping keep our city clean & safe!"
        }
        return messages.get(complaint.status, f"Update on Complaint #{complaint.complaint_id}: Status is now {complaint.status}.")


class ComplaintManager:
    """High-Level Business Logic Controller connecting database, AI, and statistics."""

    def __init__(self, db_manager: DatabaseManager, ai_analyzer: AIAnalyzer):
        self.db = db_manager
        self.ai = ai_analyzer

    def submit_new_complaint(self, data: Dict[str, Any]) -> Complaint:
        title = data.get("title", "").strip()
        description = data.get("description", "").strip()
        location = data.get("location", "Central District").strip()
        citizen_name = data.get("citizen_name", "Akash Ahmed").strip()
        citizen_contact = data.get("citizen_contact", "").strip()
        image_url = data.get("image_url", "").strip()

        # Run AI Pipeline
        ai_res = self.ai.analyze_complaint(title, description, has_image=bool(image_url))

        new_complaint = Complaint(
            title=title,
            description=description,
            location=location,
            citizen_name=citizen_name,
            citizen_contact=citizen_contact,
            category=ai_res["category"],
            priority=ai_res["priority"],
            status="Open",
            assigned_department=ai_res["recommended_department"],
            ai_summary=ai_res["ai_summary"],
            ai_confidence=ai_res["ai_confidence"],
            image_url=image_url,
            vision_analysis=ai_res["vision_analysis"]
        )

        complaint_id = self.db.add_complaint(new_complaint)
        new_complaint.complaint_id = complaint_id
        return new_complaint

    def get_statistics(self) -> Dict[str, Any]:
        all_complaints = self.db.get_all_complaints()
        return StatsCalculator.compute_full_statistics(all_complaints)
