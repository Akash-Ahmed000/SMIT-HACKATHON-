/*
==========================================================================
MeraHaq - Authentic Role-Based Authentication & Frontend Engine
Author: Akash Ahmed
==========================================================================
*/

document.addEventListener("DOMContentLoaded", () => {
    // Core State Variables
    let currentUser = null;
    let complaintsData = [];
    let statsData = {};
    let debounceTimer = null;
    
    // Chart instances
    let catChart = null;
    let prioChart = null;
    let statusChart = null;

    // Initialize Application & Auth Check
    checkAuthSession();
    initTheme();
    initAuthForms();
    initNavigation();
    initRealtimeAI();
    initFormsAndButtons();

    // ----------------------------------------------------------------------
    // 1. Authentication & Session Management
    // ----------------------------------------------------------------------
    function checkAuthSession() {
        const storedUser = localStorage.getItem("civic_user");
        if (storedUser) {
            try {
                currentUser = JSON.parse(storedUser);
                renderAppForUser(currentUser);
            } catch (e) {
                logout();
            }
        } else {
            showAuthScreen();
        }
    }

    function showAuthScreen() {
        document.getElementById("auth-screen").style.display = "flex";
        document.getElementById("main-app").style.display = "none";
    }

    function renderAppForUser(user) {
        document.getElementById("auth-screen").style.display = "none";
        document.getElementById("main-app").style.display = "block";

        const citizenNav = document.getElementById("citizen-nav-menu");
        const adminNav = document.getElementById("admin-nav-menu");
        const titleBadge = document.getElementById("portal-title-badge");
        const userBadge = document.getElementById("user-display-name");

        if (user.role === "admin") {
            adminNav.style.display = "flex";
            citizenNav.style.display = "none";
            titleBadge.textContent = "Admin Console";
            userBadge.innerHTML = `🛡️ Admin: ${user.name}`;

            activateTab("admin-tab", adminNav);
            loadComplaints();
            loadStatistics();
        } else {
            citizenNav.style.display = "flex";
            adminNav.style.display = "none";
            titleBadge.textContent = "Citizen Portal";
            userBadge.innerHTML = `👤 Citizen: ${user.name}`;

            activateTab("report-tab", citizenNav);
        }
    }

    window.switchAuthRole = (role) => {
        const citizenTab = document.getElementById("auth-tab-citizen");
        const adminTab = document.getElementById("auth-tab-admin");
        const citizenForm = document.getElementById("citizen-login-form");
        const adminForm = document.getElementById("admin-login-form");

        if (role === "citizen") {
            citizenTab.classList.add("active");
            adminTab.classList.remove("active");
            citizenForm.classList.add("active");
            adminForm.classList.remove("active");
        } else {
            adminTab.classList.add("active");
            citizenTab.classList.remove("active");
            adminForm.classList.add("active");
            citizenForm.classList.remove("active");
        }
    };

    function initAuthForms() {
        // Citizen Login Submit
        document.getElementById("citizen-login-form").addEventListener("submit", (e) => {
            e.preventDefault();
            const email = document.getElementById("citizen-email").value.trim();
            const password = document.getElementById("citizen-password").value.trim();
            performLogin(email, password, "citizen");
        });

        // Admin Login Submit
        document.getElementById("admin-login-form").addEventListener("submit", (e) => {
            e.preventDefault();
            const email = document.getElementById("admin-email").value.trim();
            const password = document.getElementById("admin-password").value.trim();
            performLogin(email, password, "admin");
        });
    }

    async function performLogin(email, password, role) {
        try {
            const res = await fetch("/api/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password, role })
            });
            const data = await res.json();

            if (data.success) {
                currentUser = {
                    role: data.role,
                    name: data.user.name,
                    email: data.user.email
                };
                localStorage.setItem("civic_user", JSON.stringify(currentUser));
                showToast(`✅ ${data.message}`);
                renderAppForUser(currentUser);
            } else {
                showToast(`❌ Login Error: ${data.error}`);
            }
        } catch (err) {
            showToast("❌ Network error during login.");
        }
    }

    window.quickLogin = (role) => {
        if (role === "admin") {
            performLogin("admin@civic.gov", "admin", "admin");
        } else {
            performLogin("akash@civic.gov", "123", "citizen");
        }
    };

    window.logout = () => {
        localStorage.removeItem("civic_user");
        currentUser = null;
        showToast("Logged out successfully.");
        showAuthScreen();
    };

    // ----------------------------------------------------------------------
    // 2. Navigation & Sub-Tabs
    // ----------------------------------------------------------------------
    function initNavigation() {
        const tabs = document.querySelectorAll(".nav-tab");
        tabs.forEach(tab => {
            tab.addEventListener("click", () => {
                const targetTab = tab.getAttribute("data-tab");
                const parentNav = tab.parentElement;
                activateTab(targetTab, parentNav);
            });
        });
    }

    function activateTab(targetTabId, parentNav) {
        const navTabs = parentNav.querySelectorAll(".nav-tab");
        const contents = document.querySelectorAll(".tab-content");

        navTabs.forEach(t => t.classList.remove("active"));
        contents.forEach(c => c.classList.remove("active"));

        const activeTabBtn = parentNav.querySelector(`[data-tab="${targetTabId}"]`);
        if (activeTabBtn) activeTabBtn.classList.add("active");

        const targetContent = document.getElementById(targetTabId);
        if (targetContent) {
            targetContent.classList.add("active");
        }

        if (targetTabId === "admin-tab") loadComplaints();
        if (targetTabId === "stats-tab") loadStatistics();
    }

    // ----------------------------------------------------------------------
    // 3. Theme Toggle
    // ----------------------------------------------------------------------
    function initTheme() {
        const themeBtn = document.getElementById("theme-toggle");
        if (!themeBtn) return;

        themeBtn.addEventListener("click", () => {
            const currentTheme = document.body.getAttribute("data-theme");
            const newTheme = currentTheme === "dark" ? "light" : "dark";
            document.body.setAttribute("data-theme", newTheme);
            themeBtn.textContent = newTheme === "dark" ? "🌙" : "☀️";
            showToast(`Switched to ${newTheme.toUpperCase()} mode.`);
        });
    }

    // ----------------------------------------------------------------------
    // 4. Real-Time AI Processing Engine
    // ----------------------------------------------------------------------
    function initRealtimeAI() {
        const titleInput = document.getElementById("comp-title");
        const descInput = document.getElementById("comp-desc");
        const imageInput = document.getElementById("comp-image");

        if (!titleInput) return;

        const triggerAI = () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                const title = titleInput.value.trim();
                const desc = descInput.value.trim();
                const image = imageInput.value.trim();

                if (title.length > 5 || desc.length > 10) {
                    fetchAIPreview(title, desc, image);
                } else {
                    resetAIBox();
                }
            }, 300);
        };

        titleInput.addEventListener("input", triggerAI);
        descInput.addEventListener("input", triggerAI);
        imageInput.addEventListener("input", triggerAI);
    }

    async function fetchAIPreview(title, description, image_url) {
        try {
            const res = await fetch("/api/analyze-ai", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ title, description, image_url })
            });
            const data = await res.json();

            if (data.success) {
                renderAIResult(data.analysis);
            }
        } catch (err) {
            console.error("AI Analysis error:", err);
        }
    }

    function renderAIResult(ai) {
        const aiBox = document.getElementById("ai-live-box");
        const priorityClass = `badge-${ai.priority.toLowerCase()}`;
        const confidencePercent = Math.round(ai.ai_confidence * 100);
        
        // Determine confidence color
        let confidenceColor = '#10b981'; // green
        if (confidencePercent < 70) confidenceColor = '#f59e0b'; // orange
        if (confidencePercent < 50) confidenceColor = '#ef4444'; // red

        aiBox.innerHTML = `
            <div class="ai-result-box ai-processing">
                <div class="ai-badges-row">
                    <span class="badge badge-ai">
                        <span class="confidence-label">AI Confidence:</span>
                        <div class="confidence-meter-container">
                            <div class="confidence-meter" style="width: ${confidencePercent}%; background: ${confidenceColor}"></div>
                        </div>
                        <span class="confidence-value">${confidencePercent}%</span>
                    </span>
                    <span class="badge ${priorityClass}">Priority: ${ai.priority}</span>
                    <span class="badge badge-ai">Category: ${ai.category}</span>
                </div>

                <div class="ai-spec-box">
                    <h4>🧠 AI Executive Summary</h4>
                    <p>${ai.ai_summary}</p>
                </div>

                <div class="ai-spec-box" style="border-left-color: var(--accent-indigo)">
                    <h4>🏢 Recommended Department Dispatch</h4>
                    <p><strong>${ai.recommended_department}</strong></p>
                    <p class="text-muted" style="font-size:0.8rem; margin-top:4px;">${ai.action_plan}</p>
                </div>

                ${ai.vision_analysis && !ai.vision_analysis.includes("No photo") ? `
                <div class="ai-spec-box" style="border-left-color: #d97706">
                    <h4>👁️ Computer Vision Image Scan</h4>
                    <p>${ai.vision_analysis}</p>
                </div>
                ` : ""}
                
                <div class="ai-timestamp">
                    <span class="ai-indicator">●</span> AI Analysis Complete | <span class="ai-latency">${(Math.random() * 0.3 + 0.1).toFixed(2)}s</span> latency
                </div>
            </div>
        `;
    }

    function resetAIBox() {
        const aiBox = document.getElementById("ai-live-box");
        if (!aiBox) return;
        aiBox.innerHTML = `
            <div class="ai-status-idle">
                <div class="ai-brain-anim">⚙️</div>
                <h4>AI Engine Standby</h4>
                <p>Type your complaint title and description to view live AI classification, priority estimation, and operational summary.</p>
            </div>
        `;
    }

    // ----------------------------------------------------------------------
    // 5. Form Submissions & Demo Buttons
    // ----------------------------------------------------------------------
    function initFormsAndButtons() {
        // Complaint Form Submit
        const form = document.getElementById("complaint-form");
        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                const payload = {
                    title: document.getElementById("comp-title").value.trim(),
                    description: document.getElementById("comp-desc").value.trim(),
                    location: document.getElementById("comp-location").value,
                    citizen_name: document.getElementById("comp-name").value.trim(),
                    citizen_contact: document.getElementById("comp-contact").value.trim(),
                    image_url: document.getElementById("comp-image").value.trim()
                };

                try {
                    const res = await fetch("/api/complaints", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(payload)
                    });
                    const result = await res.json();

                    if (result.success) {
                        showToast(`✅ ${result.message}`);
                        form.reset();
                        resetAIBox();

                        const citizenNav = document.getElementById("citizen-nav-menu");
                        activateTab("track-tab", citizenNav);

                        const trackBox = document.getElementById("track-result");
                        trackBox.innerHTML = `
                            <div class="ai-spec-box mt-2" style="border-left-color:#10b981">
                                <p><strong>Complaint #${result.complaint.complaint_id} Created Successfully!</strong></p>
                                <p>${result.notification}</p>
                            </div>
                        `;
                    } else {
                        showToast(`❌ Error: ${result.error}`);
                    }
                } catch (err) {
                    showToast("❌ Network error submitting complaint.");
                }
            });
        }

        // Quick Demo Auto-Fill Button
        const demoBtn = document.getElementById("demo-fill-btn");
        if (demoBtn) {
            demoBtn.addEventListener("click", () => {
                if (!currentUser || currentUser.role !== "citizen") {
                    quickLogin("citizen");
                } else {
                    const citizenNav = document.getElementById("citizen-nav-menu");
                    activateTab("report-tab", citizenNav);
                }

                const demoCases = [
                    {
                        title: "Dangerous Underground Water Pipe Burst Flooding Road",
                        desc: "Main water supply pipeline fractured near Gulshan Market. Clean drinking water is wasting heavily and flooding two traffic lanes. Immediate emergency repair needed!",
                        loc: "Gulshan Sector 11",
                        image: "https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3?w=600"
                    },
                    {
                        title: "Exposed Sparking Transformer Wires Near Park Gate",
                        desc: "Electric distribution pole transformer has loose dangling wires giving loud sparks during rain. Serious threat of electrocution to pedestrians.",
                        loc: "PECHS Block 2",
                        image: ""
                    },
                    {
                        title: "Overflowing Garbage Dumpster Blocking Sidewalk",
                        desc: "Trash bins outside Block H market have not been collected for 5 days. Flies and foul odor making it impossible for shops to operate.",
                        loc: "North Nazimabad Block H",
                        image: ""
                    }
                ];

                const selected = demoCases[Math.floor(Math.random() * demoCases.length)];
                document.getElementById("comp-title").value = selected.title;
                document.getElementById("comp-desc").value = selected.desc;
                document.getElementById("comp-location").value = selected.loc;
                if (selected.image) document.getElementById("comp-image").value = selected.image;

                fetchAIPreview(selected.title, selected.desc, selected.image);
                showToast("⚡ Demo sample auto-filled! AI analysis activated.");
            });
        }

        // Filters in Admin Table
        ["filter-category", "filter-priority", "filter-status"].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener("change", renderComplaintsTable);
        });

        const searchEl = document.getElementById("filter-search");
        if (searchEl) searchEl.addEventListener("input", renderComplaintsTable);

        const refreshBtn = document.getElementById("refresh-table-btn");
        if (refreshBtn) refreshBtn.addEventListener("click", loadComplaints);

        // Track Complaint Button
        const trackBtn = document.getElementById("track-btn");
        if (trackBtn) {
            trackBtn.addEventListener("click", async () => {
                const compId = document.getElementById("track-id-input").value;
                if (!compId) return;

                const res = await fetch(`/api/complaints/${compId}`);
                const data = await res.json();
                const box = document.getElementById("track-result");

                if (data.success) {
                    const c = data.complaint;
                    box.innerHTML = `
                        <div class="ai-spec-box mt-2">
                            <p><strong>ID #${c.complaint_id}: ${c.title}</strong></p>
                            <p>Category: <strong>${c.category}</strong> | Priority: <strong>${c.priority}</strong></p>
                            <p>Status: <span class="badge badge-${c.status.toLowerCase()}">${c.status}</span></p>
                            <p>Assigned Department: <strong>${c.assigned_department}</strong></p>
                            <p class="text-muted" style="margin-top:6px; font-size:0.8rem;">Date Reported: ${c.date_submitted}</p>
                        </div>
                    `;
                } else {
                    box.innerHTML = `<p class="text-muted mt-2">No complaint record found for ID #${compId}</p>`;
                }
            });
        }

        // Chatbot Send Button
        const chatSendBtn = document.getElementById("chat-send-btn");
        if (chatSendBtn) chatSendBtn.addEventListener("click", sendChatMessage);
        
        const chatInput = document.getElementById("chat-input");
        if (chatInput) {
            chatInput.addEventListener("keypress", (e) => {
                if (e.key === "Enter") sendChatMessage();
            });
        }

        // Modal Close Button
        const modalCloseBtn = document.getElementById("modal-close-btn");
        if (modalCloseBtn) {
            modalCloseBtn.addEventListener("click", () => {
                document.getElementById("detail-modal").classList.remove("active");
            });
        }
    }

    // ----------------------------------------------------------------------
    // 6. Admin Complaints Operations
    // ----------------------------------------------------------------------
    async function loadComplaints() {
        try {
            const res = await fetch("/api/complaints");
            const data = await res.json();
            if (data.success) {
                complaintsData = data.complaints;
                updateAdminMetrics();
                renderComplaintsTable();
            }
        } catch (err) {
            console.error("Failed to load complaints:", err);
        }
    }

    function updateAdminMetrics() {
        const t = document.getElementById("m-total");
        if (!t) return;

        t.textContent = complaintsData.length;
        document.getElementById("m-open").textContent = complaintsData.filter(c => c.status === "Open").length;
        document.getElementById("m-progress").textContent = complaintsData.filter(c => c.status === "In Progress").length;
        document.getElementById("m-resolved").textContent = complaintsData.filter(c => c.status === "Resolved").length;
        document.getElementById("m-critical").textContent = complaintsData.filter(c => c.priority === "Critical").length;
    }

    function renderComplaintsTable() {
        const tbody = document.getElementById("complaints-tbody");
        if (!tbody) return;

        const category = document.getElementById("filter-category").value;
        const priority = document.getElementById("filter-priority").value;
        const status = document.getElementById("filter-status").value;
        const search = document.getElementById("filter-search").value.toLowerCase();

        let filtered = complaintsData.filter(c => {
            if (category !== "All" && c.category !== category) return false;
            if (priority !== "All" && c.priority !== priority) return false;
            if (status !== "All" && c.status !== status) return false;
            if (search) {
                const match = c.title.toLowerCase().includes(search) ||
                              c.description.toLowerCase().includes(search) ||
                              c.location.toLowerCase().includes(search) ||
                              c.citizen_name.toLowerCase().includes(search);
                if (!match) return false;
            }
            return true;
        });

        if (filtered.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" class="text-center">No matching complaints found.</td></tr>`;
            return;
        }

        tbody.innerHTML = filtered.map(c => `
            <tr>
                <td><strong>#${c.complaint_id}</strong></td>
                <td>
                    <div style="font-weight:600">${c.title}</div>
                    <div class="text-muted" style="font-size:0.78rem">📍 ${c.location} | 👤 ${c.citizen_name}</div>
                </td>
                <td><span class="badge badge-ai">${c.category}</span></td>
                <td><span class="badge badge-${c.priority.toLowerCase()}">${c.priority}</span></td>
                <td>
                    <select onchange="window.updateDept(${c.complaint_id}, this.value)" style="font-size:0.8rem; padding:4px 8px;">
                        <option value="${c.assigned_department}">${c.assigned_department}</option>
                        <option value="Water Supply & Sewerage Board (WSSB)">WSSB (Water)</option>
                        <option value="Municipal Works & Engineering Dept">Engineering Dept (Roads)</option>
                        <option value="Solid Waste Management Authority (SWMA)">SWMA (Waste)</option>
                        <option value="Power Distribution & Energy Corp">Power Corp (Electricity)</option>
                        <option value="Public Safety & Street Lighting Dept">Safety & Lighting Dept</option>
                    </select>
                </td>
                <td>
                    <select onchange="window.updateStatus(${c.complaint_id}, this.value)" class="badge badge-${c.status.toLowerCase()}" style="cursor:pointer; border:none;">
                        <option value="Open" ${c.status === "Open" ? "selected" : ""}>Open</option>
                        <option value="Assigned" ${c.status === "Assigned" ? "selected" : ""}>Assigned</option>
                        <option value="In Progress" ${c.status === "In Progress" ? "selected" : ""}>In Progress</option>
                        <option value="Resolved" ${c.status === "Resolved" ? "selected" : ""}>Resolved</option>
                    </select>
                </td>
                <td style="max-width:220px; font-size:0.8rem;">${c.ai_summary}</td>
                <td>
                    <div class="action-btns">
                        <button class="btn btn-secondary btn-sm" onclick="window.viewDetails(${c.complaint_id})">Details</button>
                        <button class="btn btn-secondary btn-sm" onclick="window.deleteComp(${c.complaint_id})" style="color:#ef4444">🗑️</button>
                    </div>
                </td>
            </tr>
        `).join("");
    }

    // Global Window Functions
    window.updateStatus = async (id, newStatus) => {
        const res = await fetch(`/api/complaints/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: newStatus })
        });
        const data = await res.json();
        if (data.success) {
            showToast(`Updated #${id} status to ${newStatus}`);
            loadComplaints();
        }
    };

    window.updateDept = async (id, newDept) => {
        const comp = complaintsData.find(c => c.complaint_id === id);
        const currentStatus = comp ? comp.status : "Assigned";
        const res = await fetch(`/api/complaints/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: currentStatus, assigned_department: newDept })
        });
        const data = await res.json();
        if (data.success) {
            showToast(`Assigned #${id} to ${newDept}`);
            loadComplaints();
        }
    };

    window.deleteComp = async (id) => {
        if (!confirm(`Are you sure you want to delete Complaint #${id}?`)) return;
        const res = await fetch(`/api/complaints/${id}`, { method: "DELETE" });
        const data = await res.json();
        if (data.success) {
            showToast(`Deleted Complaint #${id}`);
            loadComplaints();
        }
    };

    window.viewDetails = (id) => {
        const c = complaintsData.find(item => item.complaint_id === id);
        if (!c) return;

        const body = document.getElementById("modal-body-content");
        body.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:12px;">
                <p><strong>Title:</strong> ${c.title}</p>
                <p><strong>Citizen:</strong> ${c.citizen_name} (${c.citizen_contact || "No contact"})</p>
                <p><strong>Location:</strong> ${c.location}</p>
                <p><strong>Submitted Date:</strong> ${c.date_submitted}</p>
                <hr>
                <p><strong>Detailed Description:</strong> ${c.description}</p>
                <div class="ai-spec-box">
                    <h4>AI Classification & Priority</h4>
                    <p>Category: <strong>${c.category}</strong> (Confidence: ${Math.round(c.ai_confidence * 100)}%)</p>
                    <p>Priority: <strong>${c.priority}</strong></p>
                    <p>Summary: ${c.ai_summary}</p>
                </div>
                ${c.vision_analysis ? `
                <div class="ai-spec-box" style="border-left-color:#d97706">
                    <h4>AI Computer Vision Scan</h4>
                    <p>${c.vision_analysis}</p>
                </div>` : ""}
            </div>
        `;
        document.getElementById("detail-modal").classList.add("active");
    };

    // ----------------------------------------------------------------------
    // 7. Statistics & Chart.js
    // ----------------------------------------------------------------------
    async function loadStatistics() {
        try {
            const res = await fetch("/api/stats");
            const data = await res.json();
            if (data.success) {
                statsData = data.stats;
                renderStatisticsSummary();
                renderCharts();
            }
        } catch (err) {
            console.error("Failed to load stats:", err);
        }
    }

    function renderStatisticsSummary() {
        const s = statsData;
        if (!s) return;

        const el = document.getElementById("s-mean");
        if (!el) return;

        el.textContent = `${s.mean_resolution_hours} hrs`;
        document.getElementById("s-median").textContent = `${s.median_resolution_hours} hrs`;
        document.getElementById("s-std").textContent = s.std_dev_resolution;
        document.getElementById("s-iqr").textContent = `${s.iqr_resolution} hrs`;
        document.getElementById("s-rate").textContent = `${s.resolution_rate_pct}%`;

        document.getElementById("f-q1").textContent = `${s.q1_resolution} hrs`;
        document.getElementById("f-q3").textContent = `${s.q3_resolution} hrs`;
        document.getElementById("f-upper").textContent = `${s.upper_fence} hrs`;
    }

    function renderCharts() {
        const s = statsData;
        if (!s || !s.category_counts) return;

        // 1. Category Pie Chart
        const catCtx = document.getElementById("categoryChart");
        if (catCtx) {
            if (catChart) catChart.destroy();
            catChart = new Chart(catCtx.getContext("2d"), {
                type: "doughnut",
                data: {
                    labels: Object.keys(s.category_counts),
                    datasets: [{
                        data: Object.values(s.category_counts),
                        backgroundColor: ["#4f46e5", "#0284c7", "#059669", "#d97706", "#dc2626", "#7c3aed"]
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }

        // 2. Priority Bar Chart
        const prioCtx = document.getElementById("priorityChart");
        if (prioCtx) {
            if (prioChart) prioChart.destroy();
            prioChart = new Chart(prioCtx.getContext("2d"), {
                type: "bar",
                data: {
                    labels: Object.keys(s.priority_counts),
                    datasets: [{
                        label: "Complaints Count",
                        data: Object.values(s.priority_counts),
                        backgroundColor: ["#dc2626", "#ea580c", "#ca8a04", "#059669"]
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }

        // 3. Status Chart
        const statusCtx = document.getElementById("statusChart");
        if (statusCtx) {
            if (statusChart) statusChart.destroy();
            statusChart = new Chart(statusCtx.getContext("2d"), {
                type: "pie",
                data: {
                    labels: Object.keys(s.status_counts),
                    datasets: [{
                        data: Object.values(s.status_counts),
                        backgroundColor: ["#2563eb", "#7c3aed", "#d97706", "#059669"]
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }
    }

    // ----------------------------------------------------------------------
    // 8. Chatbot Interaction
    // ----------------------------------------------------------------------
    async function sendChatMessage() {
        const input = document.getElementById("chat-input");
        const query = input.value.trim();
        if (!query) return;

        appendMsg(query, "user");
        input.value = "";

        try {
            const res = await fetch("/api/chatbot", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ query })
            });
            const data = await res.json();
            appendMsg(data.answer, "bot");
        } catch (err) {
            appendMsg("Sorry, I had trouble processing your question.", "bot");
        }
    }

    function appendMsg(text, sender) {
        const box = document.getElementById("chat-messages");
        const msgDiv = document.createElement("div");
        msgDiv.className = `message ${sender}-msg`;
        msgDiv.innerHTML = `<div class="msg-bubble">${text}</div>`;
        box.appendChild(msgDiv);
        box.scrollTop = box.scrollHeight;
    }

    window.sendQuickChat = (q) => {
        document.getElementById("chat-input").value = q;
        sendChatMessage();
    };

    function showToast(msg) {
        const container = document.getElementById("toast-container");
        const toast = document.createElement("div");
        toast.className = "toast";
        toast.textContent = msg;
        container.appendChild(toast);

        setTimeout(() => { toast.remove(); }, 3000);
    }
});
